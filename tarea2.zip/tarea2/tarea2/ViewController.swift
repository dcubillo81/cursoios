//
//  ViewController.swift
//  tarea2
//
//  Created by Daniel Cubillo on 14/2/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelnumero: UILabel!
    var operador1 : Float = 0
    var operador2 : Float = 0
    var resultado : Float = 0
    var operacion = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func boton7(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="7"
        }else{
            labelnumero.text=labelnumero.text!+"7"
        }
        
    }
    
    @IBAction func boton8(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="8"
        }else{
            labelnumero.text=labelnumero.text!+"8"
        }
    }
    
    @IBAction func boton9(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="9"
        }else{
            labelnumero.text=labelnumero.text!+"9"
        }
    }
    
    @IBAction func boton4(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="4"
        }else{
            labelnumero.text=labelnumero.text!+"4"
        }
    }
    
    @IBAction func boton5(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="5"
        }else{
            labelnumero.text=labelnumero.text!+"5"
        }
    }
    
    @IBAction func boton6(_ sender: Any){
        if labelnumero.text=="0"{
            labelnumero.text="6"
        }else{
            labelnumero.text=labelnumero.text!+"6"
        }
    }
    
    @IBAction func boton1(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="1"
        }else{
            labelnumero.text=labelnumero.text!+"1"
        }
    }
    
    @IBAction func boton2(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="2"
        }else{
            labelnumero.text=labelnumero.text!+"2"
        }
    }
    
    @IBAction func boton3(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="3"
        }else{
            labelnumero.text=labelnumero.text!+"3"
        }
    }
    
    @IBAction func boton0(_ sender: Any){
        if labelnumero.text=="0" {
            labelnumero.text="0"
        }else{
            labelnumero.text=labelnumero.text!+"0"
        }
    }
    
    @IBAction func botondecimal(_ sender: Any){
        
        if labelnumero.text?.contains(".")==false {
            labelnumero.text=labelnumero.text!+"."
        }
            
    }
    
    @IBAction func botonporcentaje (_ sender: Any){
        if labelnumero.text != "0" {
            var numero = (labelnumero.text as! NSString).floatValue / 100
            labelnumero.text="\(numero)"
        }
    }
    
    @IBAction func botonac (_ sender: Any){
        labelnumero.text="0"
        operacion=""
        operador1=0
        operador2=0
    }
    
    @IBAction func botonsigno (_ sender: Any){
        if labelnumero.text != "0" {
            var numero = (labelnumero.text as! NSString).floatValue * -1
            labelnumero.text="\(numero)"
        }
    }
    
    @IBAction func botondividir (_ sender: Any){
        operador1=(labelnumero.text as! NSString).floatValue
        operacion="/"
        labelnumero.text="0"
        
    }
    
    @IBAction func botonmultiplicar (_ sender: Any){
        operador1=(labelnumero.text as! NSString).floatValue
        operacion="*"
        labelnumero.text="0"
        
    }
    
    @IBAction func botonrestar (_ sender: Any){
        operador1=(labelnumero.text as! NSString).floatValue
        operacion="-"
        labelnumero.text="0"
        
    }
    
    @IBAction func botonsumar (_ sender: Any){
        operador1=(labelnumero.text as! NSString).floatValue
        operacion="+"
        labelnumero.text="0"
        
    }
    
    @IBAction func botonresultado (_ sender: Any){
        operador2=(labelnumero.text as! NSString).floatValue
        
        switch operacion {
        case "/":
            resultado=operador1/operador2
        case "*":
            resultado=operador1*operador2
        case "-":
            resultado=operador1-operador2
        case "+":
            resultado=operador1+operador2
        default:
            resultado=operador2
        }
        
        labelnumero.text="\(resultado)"
        operador1=resultado
        operador2=0
        operacion=""
        
    }
    
    
    
    
    
    


}

